from __future__ import annotations

import csv
import re
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "thesis"
OUT = ROOT / "thesis_latex"
GENERATED = OUT / "generated"
FIGURES_OUT = OUT / "figures"
TABLES_OUT = OUT / "tables"


FRONT_MATTER = [
    ("declaration", "Declaration", SOURCE / "front_matter" / "declaration.md"),
    ("dedication", "Dedication", SOURCE / "front_matter" / "dedication.md"),
    ("acknowledgement", "Acknowledgement", SOURCE / "front_matter" / "acknowledgement.md"),
    ("abstract", "Abstract", SOURCE / "front_matter" / "abstract_draft.md"),
    ("abbreviations", "List of Abbreviations", SOURCE / "front_matter" / "list_of_abbreviations.md"),
]


CHAPTERS = [
    SOURCE / "chapters" / "01_introduction.md",
    SOURCE / "chapters" / "02_literature_review.md",
    SOURCE / "chapters" / "03_theoretical_foundations.md",
    SOURCE / "chapters" / "04_approach.md",
    SOURCE / "chapters" / "05_analysis_design.md",
    SOURCE / "chapters" / "06_implementation.md",
    SOURCE / "chapters" / "07_evaluation.md",
    SOURCE / "chapters" / "08_conclusion.md",
]


def read_metadata() -> dict[str, str]:
    data: dict[str, str] = {}
    for line in (SOURCE / "metadata.yaml").read_text(encoding="utf-8").splitlines():
        if ":" in line and not line.startswith(" ") and not line.startswith("-"):
            key, value = line.split(":", 1)
            data[key] = value.strip().strip('"')
    return data


def escape_tex(text: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(char, char) for char in text)


def convert_inline(text: str) -> str:
    code_spans: list[str] = []

    def stash_code(match: re.Match[str]) -> str:
        code_spans.append(match.group(1))
        return f"@@CODE{len(code_spans) - 1}@@"

    text = re.sub(r"`([^`]+)`", stash_code, text)
    text = escape_tex(text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"\\textbf{\1}", text)
    for index, code in enumerate(code_spans):
        text = text.replace(f"@@CODE{index}@@", r"\texttt{" + escape_tex(code) + "}")
    return text


def markdown_to_tex(path: Path, chapter: bool = False) -> str:
    lines = path.read_text(encoding="utf-8").splitlines()
    output: list[str] = []
    in_itemize = False
    table_lines: list[str] = []

    def flush_itemize() -> None:
        nonlocal in_itemize
        if in_itemize:
            output.append(r"\end{itemize}")
            output.append("")
            in_itemize = False

    def flush_table() -> None:
        nonlocal table_lines
        if len(table_lines) < 2:
            table_lines = []
            return
        rows = []
        for raw in table_lines:
            if re.match(r"^\|\s*-", raw):
                continue
            rows.append([convert_inline(cell.strip()) for cell in raw.strip("|").split("|")])
        if rows:
            column_count = len(rows[0])
            output.append(r"\begin{table}[htbp]")
            output.append(r"\centering")
            output.append(r"\small")
            output.append(r"\begin{tabularx}{\textwidth}{" + "X" * column_count + "}")
            output.append(r"\toprule")
            output.append(" & ".join(rows[0]) + r" \\")
            output.append(r"\midrule")
            for row in rows[1:]:
                output.append(" & ".join(row) + r" \\")
            output.append(r"\bottomrule")
            output.append(r"\end{tabularx}")
            output.append(r"\end{table}")
            output.append("")
        table_lines = []

    first_heading_done = False
    for raw in lines:
        stripped = raw.strip()
        if stripped.startswith("|"):
            flush_itemize()
            table_lines.append(stripped)
            continue
        flush_table()

        if not stripped:
            flush_itemize()
            output.append("")
            continue
        if stripped.startswith("# "):
            flush_itemize()
            title = convert_inline(stripped[2:])
            if chapter and not first_heading_done:
                output.append(r"\chapter{" + title + "}")
                first_heading_done = True
            else:
                output.append(r"\section*{" + title + "}")
            output.append("")
        elif stripped.startswith("## "):
            flush_itemize()
            output.append(r"\section{" + convert_inline(stripped[3:]) + "}")
            output.append("")
        elif stripped.startswith("### "):
            flush_itemize()
            output.append(r"\subsection{" + convert_inline(stripped[4:]) + "}")
            output.append("")
        elif stripped.startswith("- "):
            if not in_itemize:
                output.append(r"\begin{itemize}")
                in_itemize = True
            output.append(r"\item " + convert_inline(stripped[2:]))
        else:
            flush_itemize()
            output.append(convert_inline(stripped))
            output.append("")
    flush_table()
    flush_itemize()
    return "\n".join(output).strip() + "\n"


def copy_assets() -> None:
    FIGURES_OUT.mkdir(parents=True, exist_ok=True)
    TABLES_OUT.mkdir(parents=True, exist_ok=True)
    for fig in (SOURCE / "figures").glob("*.png"):
        shutil.copy2(fig, FIGURES_OUT / fig.name)
    shutil.copy2(ROOT / "docs" / "research_architecture_tikz.tex", FIGURES_OUT / "research_architecture_tikz.tex")
    for table in (SOURCE / "tables").glob("*.csv"):
        shutil.copy2(table, TABLES_OUT / table.name)


def write_front_matter() -> None:
    for filename, _title, source_path in FRONT_MATTER:
        (GENERATED / f"{filename}.tex").write_text(markdown_to_tex(source_path), encoding="utf-8")


def write_chapters() -> None:
    for chapter_path in CHAPTERS:
        stem = chapter_path.stem
        content = markdown_to_tex(chapter_path, chapter=True)
        if chapter_path.name == "04_approach.md":
            content += "\n" + r"\input{figures/research_architecture_tikz.tex}" + "\n"
        if chapter_path.name == "05_analysis_design.md":
            content += "\n" + figure_tex("figure_5_1_system_architecture.png", "System architecture of the adaptive fusion framework.", "fig:system_architecture") + "\n"
        if chapter_path.name == "07_evaluation.md":
            content += "\n" + figure_tex("figure_7_1_method_macro_f1.png", "Final test macro F1 comparison across selected methods.", "fig:method_macro_f1") + "\n"
            content += "\n" + csv_table_tex(TABLES_OUT / "table_7_1_final_method_comparison.csv", "Final test method comparison.", "tab:final_method_comparison") + "\n"
            content += "\n" + figure_tex("figure_7_2_ablation_macro_f1.png", "Ablation results for different RL fusion state representations.", "fig:ablation_macro_f1") + "\n"
            content += "\n" + figure_tex("figure_7_4_robustness_image_quality.png", "Image quality degradation and image-weight adaptation.", "fig:robustness_image_quality") + "\n"
        (GENERATED / f"{stem}.tex").write_text(content, encoding="utf-8")


def figure_tex(filename: str, caption: str, label: str) -> str:
    return "\n".join(
        [
            r"\begin{figure}[htbp]",
            r"\centering",
            rf"\includegraphics[width=0.9\textwidth]{{figures/{filename}}}",
            rf"\caption{{{escape_tex(caption)}}}",
            rf"\label{{{label}}}",
            r"\end{figure}",
        ]
    )


def csv_table_tex(path: Path, caption: str, label: str) -> str:
    rows = list(csv.reader(path.open(encoding="utf-8")))
    column_count = len(rows[0])
    output = [
        r"\begin{table}[htbp]",
        r"\centering",
        r"\scriptsize",
        rf"\caption{{{escape_tex(caption)}}}",
        rf"\label{{{label}}}",
        r"\begin{tabularx}{\textwidth}{" + "X" * column_count + "}",
        r"\toprule",
        " & ".join(escape_tex(cell) for cell in rows[0]) + r" \\",
        r"\midrule",
    ]
    for row in rows[1:]:
        output.append(" & ".join(escape_tex(cell) for cell in row) + r" \\")
    output.extend([r"\bottomrule", r"\end{tabularx}", r"\end{table}"])
    return "\n".join(output)


def write_references() -> None:
    references = markdown_to_tex(SOURCE / "references" / "initial_ieee_references.md")
    (GENERATED / "references.tex").write_text(references, encoding="utf-8")
    appendix = markdown_to_tex(SOURCE / "appendices" / "artifact_manifest.md")
    (GENERATED / "appendix_artifacts.tex").write_text(appendix, encoding="utf-8")


def write_main() -> None:
    meta = read_metadata()
    chapter_inputs = "\n".join(rf"\input{{generated/{path.stem}.tex}}" for path in CHAPTERS)
    main = rf"""\documentclass[12pt,a4paper,oneside]{{report}}

\usepackage[a4paper,left=1.25in,right=1in,top=1in,bottom=1in]{{geometry}}
\usepackage{{times}}
\usepackage{{setspace}}
\usepackage{{graphicx}}
\usepackage{{booktabs}}
\usepackage{{tabularx}}
\usepackage{{array}}
\usepackage{{tikz}}
\usetikzlibrary{{positioning,arrows.meta}}
\usepackage[hidelinks]{{hyperref}}
\usepackage{{titlesec}}
\usepackage{{tocloft}}
\usepackage{{caption}}
\usepackage{{float}}
\usepackage{{enumitem}}

\onehalfspacing
\setlength{{\parindent}}{{0.25in}}
\setlength{{\parskip}}{{0.35em}}

\titleformat{{\chapter}}[display]
  {{\normalfont\bfseries\centering}}
  {{\chaptertitlename\ \thechapter}}
  {{12pt}}
  {{\Large}}

\begin{{document}}

\pagenumbering{{roman}}

\begin{{titlepage}}
\centering
\vspace*{{1.0in}}
{{\Large\bfseries {escape_tex(meta["title"])}\par}}
\vspace{{0.8in}}
{{\large {escape_tex(meta["candidate_name"])}\par}}
{{\large {escape_tex(meta["registration_number"])}\par}}
\vspace{{0.5in}}
{{\large BSc. (Hons) in Artificial Intelligence\par}}
\vfill
{{\large {escape_tex(meta["department"])}\par}}
{{\large {escape_tex(meta["faculty"])}\par}}
{{\large {escape_tex(meta["university"])}\par}}
{{\large {escape_tex(meta["country"])}\par}}
\vspace{{0.4in}}
{{\large {escape_tex(meta["submission_month_year"])}\par}}
\end{{titlepage}}

\begin{{titlepage}}
\centering
\vspace*{{0.8in}}
{{\Large\bfseries {escape_tex(meta["title"])}\par}}
\vspace{{0.5in}}
{{\large {escape_tex(meta["candidate_name"])}\par}}
{{\large {escape_tex(meta["registration_number"])}\par}}
\vspace{{0.5in}}
Thesis submitted in partial fulfillment of the requirements for the Research Project in Artificial Intelligence for the degree of BSc. (Hons) in Artificial Intelligence
\vfill
{{\large {escape_tex(meta["department"])}\par}}
{{\large {escape_tex(meta["faculty"])}\par}}
{{\large {escape_tex(meta["university"])}\par}}
{{\large {escape_tex(meta["country"])}\par}}
\vspace{{0.4in}}
{{\large {escape_tex(meta["submission_month_year"])}\par}}
\end{{titlepage}}

\input{{generated/declaration.tex}}
\clearpage
\input{{generated/dedication.tex}}
\clearpage
\input{{generated/acknowledgement.tex}}
\clearpage
\input{{generated/abstract.tex}}
\clearpage

\tableofcontents
\clearpage
\listoffigures
\clearpage
\listoftables
\clearpage
\input{{generated/abbreviations.tex}}
\clearpage

\pagenumbering{{arabic}}
{chapter_inputs}

\clearpage
\input{{generated/references.tex}}

\appendix
\input{{generated/appendix_artifacts.tex}}

\end{{document}}
"""
    (OUT / "main.tex").write_text(main, encoding="utf-8")


def write_readme() -> None:
    readme = """# LaTeX Thesis Project

This folder is an Overleaf-ready LaTeX version of the thesis draft.

## How to use

1. Upload the entire `thesis_latex` folder to Overleaf, or zip the contents and upload them as a new project.
2. Set `main.tex` as the main file.
3. Compile with pdfLaTeX.

If compiling locally, install a LaTeX distribution such as MiKTeX or TeX Live, then run:

```bash
pdflatex main.tex
pdflatex main.tex
```

The generated chapter files are in `generated/`. Re-run `python build_latex_project.py` from this folder after editing markdown sources under `thesis/`.
"""
    (OUT / "README.md").write_text(readme, encoding="utf-8")


def main() -> None:
    GENERATED.mkdir(parents=True, exist_ok=True)
    copy_assets()
    write_front_matter()
    write_chapters()
    write_references()
    write_main()
    write_readme()
    print(OUT / "main.tex")


if __name__ == "__main__":
    main()
